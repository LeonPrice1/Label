import tkinter as tk
from tkinter import messagebox
from tkinter import ttk  # for nicer listbox scrollbars if desired
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import os
import math
from datetime import datetime
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT

# Global list to store orders
orders = []

# --- Helper Functions ---

def mm_to_pt(mm):
    return mm * 2.83465

def set_row_height(row, height_pt):
    tr = row._tr
    trPr = tr.get_or_add_trPr()
    trHeight = OxmlElement('w:trHeight')
    trHeight.set(qn('w:val'), str(int(height_pt)))
    trPr.append(trHeight)

    trHeight.set(qn('w:exact'), "-1")

def remove_cell_borders(cell):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    for border in tcPr.xpath(".//w:tcBorders"):
        border.getparent().remove(border)

def set_cell_margins(cell, **kwargs):
    # kwargs: top, left, bottom, right in dxa (1/20 pt)
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for margin, value in kwargs.items():
        node = OxmlElement(f"w:{margin}")
        node.set(qn('w:w'), str(value))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def clear_cell(cell):
    # Remove all paragraphs in a cell.
    for para in list(cell.paragraphs):
        para._element.getparent().remove(para._element)

# --- Order Functions ---

def add_order():
    project = project_var.get().strip()
    date = date_var.get().strip()
    model = model_var.get().strip()
    try:
        start_lcm = int(start_lcm_var.get())
        quantity = int(quantity_var.get())
    except ValueError:
        messagebox.showerror("Error", "Start LCM and Quantity must be valid numbers!")
        return
    if not (project and date and model):
        messagebox.showerror("Error", "Please fill in all text fields.")
        return
    order = {
        'project': project,
        'date': date,
        'model': model,
        'start_lcm': start_lcm,
        'quantity': quantity
    }
    orders.append(order)
    order_listbox.insert(tk.END, f"{project}, {date}, {model}, Start LCM: {start_lcm}, Qty: {quantity}")
    project_var.set("")
    date_var.set("")
    model_var.set("")
    start_lcm_var.set("")
    quantity_var.set("")

def clear_orders():
    global orders
    orders = []
    order_listbox.delete(0, tk.END)

# --- Label Generation Function ---

def generate_labels():
    if not orders:
        messagebox.showerror("Error", "No orders added. Please add at least one order.")
        return
    total_quantity = sum(order['quantity'] for order in orders)
    if total_quantity > 65:
        messagebox.showerror("Error", "Total quantity exceeds 65 labels for one Avery sheet.")
        return

    new_doc = Document()
    # Set section margins – now a top margin and left margin are added.
    section = new_doc.sections[0]
    section.top_margin = Pt(0)    # Creates a margin at the top of the page
    section.bottom_margin = Pt(0)
    section.left_margin = Pt(10)   # Creates a margin on the left of the page
    section.right_margin = Pt(0)

    # Use sticker dimensions: 38.1 mm x 21.2 mm
    cols = 5
    rows_needed = math.ceil(total_quantity / cols)
    col_width_pt = mm_to_pt(38.1)
    cell_height_pt = mm_to_pt(21.2)

    table = new_doc.add_table(rows=rows_needed, cols=cols)
    table.style = 'Table Grid'
    
    # Increase horizontal spacing between cells and add a left indent
    tblPr = table._tblPr
    tblCellSpacing = OxmlElement('w:tblCellSpacing')
    tblCellSpacing.set(qn('w:w'), "60")  # Increased spacing between each label (in dxa)
    tblCellSpacing.set(qn('w:type'), "dxa")
    tblPr.append(tblCellSpacing)
    
    tblInd = OxmlElement('w:tblInd')
    tblInd.set(qn('w:w'), "60")  # Left indent for the table (in dxa)
    tblInd.set(qn('w:type'), "dxa")
    tblPr.append(tblInd)
    
    for row in table.rows:
        set_row_height(row, cell_height_pt)
        for cell in row.cells:
            cell.width = Pt(col_width_pt * 1.5)
            remove_cell_borders(cell)
            # Set outer cell margins: here we add a top margin inside each cell
            set_cell_margins(cell, top=30, left=0, bottom=0, right=0)
            clear_cell(cell)
    
    label_index = 0
    for order in orders:
        for i in range(order['quantity']):
            if label_index >= total_quantity:
                break
            lcm_number = f"{order['start_lcm'] + i:03}"
            r = label_index // cols
            c = label_index % cols
            cell = table.cell(r, c)
            clear_cell(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP

            # Create a nested 2x2 table inside the outer cell for precise alignment.
            nested = cell.add_table(rows=2, cols=2)
            for nrow in nested.rows:
                set_row_height(nrow, 25)  # Reduced nested row height to condense vertical space
                for ncell in nrow.cells:
                    remove_cell_borders(ncell)
                    ncell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
                    # Set nested cell margins to zero
                    set_cell_margins(ncell, top=0, left=0, bottom=0, right=0)
                    clear_cell(ncell)

            # Top Left: "Project" heading and {Project} value
            tl = nested.cell(0, 0)
            p_tl_head = tl.add_paragraph()
            p_tl_head.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p_tl_head.paragraph_format.line_spacing = 1.0
            p_tl_head.paragraph_format.space_before = Pt(0)
            p_tl_head.paragraph_format.space_after = Pt(0)
            run_tl_head = p_tl_head.add_run("Project")
            run_tl_head.font.size = Pt(9)
            run_tl_head.font.name = 'Calibri'
            p_tl_val = tl.add_paragraph()
            p_tl_val.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p_tl_val.paragraph_format.line_spacing = 1.0
            p_tl_val.paragraph_format.space_before = Pt(0)
            p_tl_val.paragraph_format.space_after = Pt(0)
            run_tl_val = p_tl_val.add_run(order['project'])
            run_tl_val.font.size = Pt(14)
            run_tl_val.font.name = 'Calibri'

            # Top Right: "Date" heading and {Date} value
            tr = nested.cell(0, 1)
            p_tr_head = tr.add_paragraph()
            p_tr_head.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_tr_head.paragraph_format.line_spacing = 1.0
            p_tr_head.paragraph_format.space_before = Pt(0)
            p_tr_head.paragraph_format.space_after = Pt(0)
            run_tr_head = p_tr_head.add_run("Date")
            run_tr_head.font.size = Pt(9)
            run_tr_head.font.name = 'Calibri'
            p_tr_val = tr.add_paragraph()
            p_tr_val.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_tr_val.paragraph_format.line_spacing = 1.0
            p_tr_val.paragraph_format.space_before = Pt(0)
            p_tr_val.paragraph_format.space_after = Pt(0)
            run_tr_val = p_tr_val.add_run(order['date'])
            run_tr_val.font.size = Pt(14)
            run_tr_val.font.name = 'Calibri'
            run_tr_val.bold = True

            # Bottom Left: "Model" heading and {Model} value
            bl = nested.cell(1, 0)
            p_bl_head = bl.add_paragraph()
            p_bl_head.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p_bl_head.paragraph_format.line_spacing = 1.0
            p_bl_head.paragraph_format.space_before = Pt(0)
            p_bl_head.paragraph_format.space_after = Pt(0)
            run_bl_head = p_bl_head.add_run("Model")
            run_bl_head.font.size = Pt(9)
            run_bl_head.font.name = 'Calibri'
            p_bl_val = bl.add_paragraph()
            p_bl_val.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p_bl_val.paragraph_format.line_spacing = 1.0
            p_bl_val.paragraph_format.space_before = Pt(0)
            p_bl_val.paragraph_format.space_after = Pt(0)
            run_bl_val = p_bl_val.add_run(order['model'])
            run_bl_val.font.size = Pt(12)
            run_bl_val.font.name = 'Calibri'

            # Bottom Right: "LCM Number" heading and {LCM} value
            br = nested.cell(1, 1)
            p_br_head = br.add_paragraph()
            p_br_head.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_br_head.paragraph_format.line_spacing = 1.0
            p_br_head.paragraph_format.space_before = Pt(0)
            p_br_head.paragraph_format.space_after = Pt(0)
            run_br_head = p_br_head.add_run("LCM Number")
            run_br_head.font.size = Pt(9)
            run_br_head.font.name = 'Calibri'
            p_br_val = br.add_paragraph()
            p_br_val.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_br_val.paragraph_format.line_spacing = 1.0
            p_br_val.paragraph_format.space_before = Pt(0)
            p_br_val.paragraph_format.space_after = Pt(0)
            run_br_val = p_br_val.add_run(lcm_number)
            run_br_val.font.size = Pt(16)
            run_br_val.font.name = 'Calibri'
            run_br_val.bold = True

            label_index += 1

    output_filename = f"external_labels_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx"
    try:
        new_doc.save(output_filename)
        messagebox.showinfo("Success", f"Labels generated successfully: {output_filename}")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to save the file: {e}")
        print(f"Error saving file: {e}")

    clear_orders()

# --- GUI Setup ---

root = tk.Tk()
root.title("Label Generator")
tk.Label(root, text="Project Number:").grid(row=0, column=0, padx=10, pady=5, sticky="e")
project_var = tk.StringVar()
tk.Entry(root, textvariable=project_var).grid(row=0, column=1, padx=10, pady=5)
tk.Label(root, text="Date (DD.MM.YY):").grid(row=1, column=0, padx=10, pady=5, sticky="e")
date_var = tk.StringVar()
tk.Entry(root, textvariable=date_var).grid(row=1, column=1, padx=10, pady=5)
tk.Label(root, text="Model:").grid(row=2, column=0, padx=10, pady=5, sticky="e")
model_var = tk.StringVar()
tk.Entry(root, textvariable=model_var).grid(row=2, column=1, padx=10, pady=5)
tk.Label(root, text="Start LCM Number:").grid(row=3, column=0, padx=10, pady=5, sticky="e")
start_lcm_var = tk.StringVar()
tk.Entry(root, textvariable=start_lcm_var).grid(row=3, column=1, padx=10, pady=5)
tk.Label(root, text="Quantity:").grid(row=4, column=0, padx=10, pady=5, sticky="e")
quantity_var = tk.StringVar()
tk.Entry(root, textvariable=quantity_var).grid(row=4, column=1, padx=10, pady=5)
tk.Button(root, text="Add Order", command=add_order).grid(row=5, column=0, columnspan=2, pady=5)
tk.Button(root, text="Generate Labels", command=generate_labels).grid(row=6, column=0, columnspan=2, pady=10)
tk.Label(root, text="Orders Added:").grid(row=7, column=0, padx=10, pady=5, sticky="w")
order_listbox = tk.Listbox(root, width=50)
order_listbox.grid(row=8, column=0, columnspan=2, padx=10, pady=5)
tk.Button(root, text="Clear Orders", command=clear_orders).grid(row=9, column=0, columnspan=2, pady=5)
root.mainloop()